      <header>
            <div class="container"><a class="header-logo" href="<?php echo get_site_url(); ?>"><img src="<?php echo get_stylesheet_directory_uri(). '/assets/images/logo.svg' ?>" alt="شفافیت برای ایران"></a>
                <ul class="header-menu">
                    <li class="header-item"><a href="#" title="سامانه‌ها"><i class="icon icon-solar"></i><span>سامانه‌ها</span></a></li>
                    <li class="header-item"><a href="#" title="بلاگ"><i class="icon icon-blog"></i><span>بلاگ</span></a></li>
                    <li class="header-item"><a href="#" title="پروژه‌ها"><i class="icon icon-projects"></i><span>پروژه‌ها</span></a></li>
                    <li class="header-item"><a href="#" title="آکادمی"><i class="icon icon-academy"></i><span>آکادمی</span></a></li>
                    <li class="header-item"><a href="#" title="نقشه"><i class="icon icon-pin"></i><span>نقشه</span></a></li>
                    <li class="header-item"><a href="#" title="انجمن"><i class="icon icon-forum"></i><span>انجمن</span></a></li>
                </ul>
            </div>
        </header>