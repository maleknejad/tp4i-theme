<?php


get_header();?>

<!-- content-->
<div class="main-content">
   

    <section class="container my-5 p-5 align-centet text-center">

<h1>صفحه مورد نظر پیدا نشد</h1>
<h1>خطای 404</h1>

    </section>
   
</div>

<?php get_footer();?>