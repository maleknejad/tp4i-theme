﻿$('.grid').isotope({
      // options
      itemSelector: '.grid-item',
      layoutMode: 'masonry',
       masonry: {
             columnWidth: '.grid-sizer'
       }
});